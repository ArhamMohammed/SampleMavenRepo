package com.telusko.SpringDemo;

public class Alien {
public void code() 
{
	System.out.println("Im Coding..");
}
}
