package com.telusko.SpringDemo;

public class Desktop implements Computer
{
	public void compile() 
	{
		System.out.println("Code Compiled in a Desktop");
	}
}