package com.telusko.SpringDemo;

public interface Computer
{
void compile();
}
