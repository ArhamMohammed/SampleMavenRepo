package com.telusko.SpringDemo;

public class Alien
{ 
	int age;
	
	public Alien() {
		System.out.println("Alien Object Created..");	
	}
public void code() 
{
	System.out.println("Im Coding..");
}
}
