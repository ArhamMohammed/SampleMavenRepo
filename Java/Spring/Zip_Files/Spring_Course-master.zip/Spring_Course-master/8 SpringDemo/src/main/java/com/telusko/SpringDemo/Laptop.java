package com.telusko.SpringDemo;

public class Laptop 
{
	public void compile() 
	{
		System.out.println("Code Compiled");
	}
}
